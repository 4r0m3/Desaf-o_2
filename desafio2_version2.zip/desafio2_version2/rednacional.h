#ifndef REDNACIONAL_H
#define REDNACIONAL_H
#include "Entidad.h"
#include <string>
#include "EstacionServicio.h"

using namespace std;
using namespace EstacionServicioNS;

namespace RedNacionalNS {

class RedNacional : public Entidad {
public:
    // Constructor y destructor
    RedNacional(const string& codigo, const string& nombre);
    ~RedNacional();  // Para liberar memoria

    // Métodos
    void agregarEstacion(EstacionServicio* estacion);
    void eliminarEstacion(const string& codigo);
    EstacionServicio* buscarEstacion(const string& codigo);
    double calcularVentasTotales() const;
    void fijarPreciosCombustible(int region, double precios[]);

private:
    EstacionServicio** estaciones;  // Arreglo dinámico de punteros a EstacionServicio
    int numEstaciones;  // Número actual de estaciones
    int capacidadEstaciones;  // Capacidad del arreglo dinámico

    double precios_combustible[3];  // Precios de combustible por región

    void redimensionarEstaciones(int nuevaCapacidad);  // Redimensionar el arreglo dinámico
};

}

#endif // REDNACIONAL_H

