#include <iostream>
#include <cstdlib>
#include <ctime>
#include "RedNacional.h"
#include "EstacionServicio.h"
#include "Surtidor.h"

using namespace std;
using namespace RedNacionalNS;
using namespace EstacionServicioNS;
using namespace SurtidorNS;

// Prototipos de funciones
void mostrarMenuPrincipal();
int Obteneropcion();
void mostrarMenuRedNacional(RedNacional& red);
void mostrarMenuEstacion(EstacionServicio* estacion);

void gestionarFugas(RedNacional& red);
void simularVenta(RedNacional& red);
// Función principal
int main() {
    srand(time(0));  // Inicializar la semilla para la generación de números aleatorios

    RedNacional red("R001", "Red Nacional de Estaciones");

    int opcion;

    do {
        mostrarMenuPrincipal();
        cin >> opcion;

        switch(opcion) {
        case 1:
            mostrarMenuRedNacional(red);
            break;
        case 2: {
            string codigo;
            cout << "Ingrese el código de la estación: ";
            cin >> codigo;
            EstacionServicio* estacion = red.buscarEstacion(codigo);
            if (estacion) {
                mostrarMenuEstacion(estacion);
            } else {
                cout << "Estación no encontrada." << endl;
            }
            break;
        }
        case 3:
            gestionarFugas(red);
            break;
        case 4:
            simularVenta(red);
            break;
        case 0:
            cout << "Saliendo..." << endl;
            break;
        default:
            cout << "Opción inválida, intente de nuevo." << endl;
        }

    } while (opcion != 0);

    return 0;
}

void mostrarMenuPrincipal() {
    cout << "\n--- Menú Principal ---\n";
    cout << "1. Gestión de la Red Nacional\n";
    cout << "2. Gestión de Estación de Servicio\n";
    cout << "3. Verificación de Fugas\n";
    cout << "4. Simulación de Ventas\n";
    cout << "0. Salir\n";
    cout << "Seleccione una opción: ";
}
// Función para obtener la opción del usuario
int obtenerOpcion() {
    int opcion;
    while (true) {
        cin >> opcion;
        if (cin.fail()) { // Si hay un error en la entrada
            cin.clear(); // Limpiar el estado de error
            cin.ignore(10000, '\n'); // Ignorar la línea incorrecta
            cout << "Entrada inválida. Por favor, ingrese un número: ";
        } else {
            cin.ignore(10000, '\n'); // Limpiar el resto de la línea
            return opcion; // Retornar la opción válida
        }
    }
}
void mostrarMenuRedNacional(RedNacional& red) {
    int opcion;
    do {
        cout << "\n--- Menú Red Nacional ---\n";
        cout << "1. Agregar Estación de Servicio\n";
        cout << "2. Eliminar Estación de Servicio\n";
        cout << "3. Calcular Ventas Totales\n";
        cout << "4. Fijar Precios del Combustible\n";
        cout << "0. Volver al Menú Principal\n";
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            string codigo, nombre, ubicacion, gerente, region;
            cout << "Ingrese código de la estación: ";
            cin >> codigo;
            cout << "Ingrese nombre: ";
            cin >> nombre;
            cout << "Ingrese ubicación: ";
            cin >> ubicacion;
            cout << "Ingrese nombre del gerente: ";
            cin >> gerente;
            cout << "Ingrese región: ";
            cin >> region;

            EstacionServicio* estacion = new EstacionServicio(codigo, nombre, ubicacion, gerente, region);
            red.agregarEstacion(estacion);
            cout << "Estación agregada correctamente." << endl;
            break;
        }
        case 2: {
            string codigo;
            cout << "Ingrese el código de la estación a eliminar: ";
            cin >> codigo;
            red.eliminarEstacion(codigo);
            cout << "Estación eliminada si cumplía las condiciones." << endl;
            break;
        }
        case 3:
            cout << "Ventas Totales: " << red.calcularVentasTotales() << endl;
            break;
        case 4: {
            double precios[3];
            cout << "Ingrese precios por categoría de combustible (3 categorías): ";
            for (int i = 0; i < 3; ++i) {
                cin >> precios[i];
            }
            red.fijarPreciosCombustible(0, precios);  // Aplicar precios a todas las regiones
            cout << "Precios actualizados." << endl;
            break;
        }
        case 0:
            break;
        default:
            cout << "Opción inválida." << endl;
        }
    } while (opcion != 0);
}

void mostrarMenuEstacion(EstacionServicio* estacion) {
    int opcion;
    do {
        cout << "\n--- Menú Estación de Servicio ---\n";
        cout << "1. Agregar Surtidor\n";
        cout << "2. Eliminar Surtidor\n";
        cout << "3. Activar Surtidor\n";
        cout << "4. Desactivar Surtidor\n";
        cout << "5. Consultar Histórico de Transacciones\n";
        cout << "6. Reportar Litros Vendidos\n";
        cout << "7. Simular Venta\n";
        cout << "8. Asignar Capacidad del Tanque\n";
        cout << "0. Volver al Menú Principal\n";
        cout << "Seleccione una opción: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            string codigo, nombre, modelo;
            cout << "Ingrese código del surtidor: ";
            cin >> codigo;
            cout << "Ingrese nombre del surtidor: ";
            cin >> nombre;
            cout << "Ingrese modelo: ";
            cin >> modelo;
            Surtidor* surtidor = new Surtidor(codigo, nombre, modelo);
            estacion->agregarSurtidor(surtidor);
            cout << "Surtidor agregado correctamente." << endl;
            break;
        }
        case 2: {
            string codigo;
            cout << "Ingrese el código del surtidor a eliminar: ";
            cin >> codigo;
            estacion->eliminarSurtidor(codigo);
            cout << "Surtidor eliminado." << endl;
            break;
        }
        case 3: {
            string codigo;
            cout << "Ingrese el código del surtidor a activar: ";
            cin >> codigo;
            estacion->activarSurtidor(codigo);
            cout << "Surtidor activado." << endl;
            break;
        }
        case 4: {
            string codigo;
            cout << "Ingrese el código del surtidor a desactivar: ";
            cin >> codigo;
            estacion->desactivarSurtidor(codigo);
            cout << "Surtidor desactivado." << endl;
            break;
        }
        case 5:
            estacion->consultarHistoricoTransacciones();
            break;
        case 6:
            estacion->asignarCapacidadTanque();
            cout << "Capacidad del tanque asignada." << endl;
            break;
        case 0:
            break;
        default:
            cout << "Opción inválida." << endl;
        }
    } while (opcion != 0);
}
void gestionarFugas(RedNacional& red) {
    string codigo;
    cout << "Ingrese el código de la estación para verificar fugas: ";
    cin >> codigo;
    EstacionServicio* estacion = red.buscarEstacion(codigo);
    if (estacion) {
        // Verificar las fugas
        cout << "Verificación de fugas en la estación " << estacion->getCodigo() << endl;
        // Implementar lógica de verificación de fugas aquí
    } else {
        cout << "Estación no encontrada." << endl;
    }
}

void simularVenta(RedNacional& red) {
    string codigo;
    cout << "Ingrese el código de la estación para la simulación de venta: ";
    cin >> codigo;
    EstacionServicio* estacion = red.buscarEstacion(codigo);
    if (estacion) {
        estacion->simularVenta(10, 1);  // Ejemplo de simulación de venta
    } else {
        cout << "Estación no encontrada." << endl;
    }
}



