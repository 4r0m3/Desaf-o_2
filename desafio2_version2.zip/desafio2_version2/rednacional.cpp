#include "RedNacional.h"
#include <iostream>

using namespace std;
using namespace RedNacionalNS;

// Constructor
RedNacional::RedNacional(const string& codigo, const string& nombre)
    : Entidad(codigo, nombre), numEstaciones(0), capacidadEstaciones(2) {
    estaciones = new EstacionServicio*[capacidadEstaciones];  // Inicializar el arreglo dinámico
}

// Destructor
RedNacional::~RedNacional() {
    for (int i = 0; i < numEstaciones; ++i) {
        delete estaciones[i];  // Liberar memoria de cada estación
    }
    delete[] estaciones;  // Liberar el arreglo dinámico
}

// Redimensionar el arreglo dinámico de estaciones
void RedNacional::redimensionarEstaciones(int nuevaCapacidad) {
    EstacionServicio** nuevoArreglo = new EstacionServicio*[nuevaCapacidad];
    for (int i = 0; i < numEstaciones; ++i) {
        nuevoArreglo[i] = estaciones[i];
    }
    delete[] estaciones;
    estaciones = nuevoArreglo;
    capacidadEstaciones = nuevaCapacidad;
}

// Agregar una nueva estación
void RedNacional::agregarEstacion(EstacionServicio* estacion) {
    if (numEstaciones == capacidadEstaciones) {
        redimensionarEstaciones(capacidadEstaciones * 2);  // Duplicar capacidad
    }
    estaciones[numEstaciones++] = estacion;
}

// Eliminar una estación
void RedNacional::eliminarEstacion(const string& codigo) {
    for (int i = 0; i < numEstaciones; ++i) {
        if (estaciones[i]->getCodigo() == codigo) {
            delete estaciones[i];  // Liberar memoria de la estación
            // Desplazar las estaciones
            for (int j = i; j < numEstaciones - 1; ++j) {
                estaciones[j] = estaciones[j + 1];
            }
            --numEstaciones;
            break;
        }
    }
}

// Buscar una estación por su código
EstacionServicio* RedNacional::buscarEstacion(const string& codigo) {
    for (int i = 0; i < numEstaciones; ++i) {
        if (estaciones[i]->getCodigo() == codigo) {
            return estaciones[i];
        }
    }
    return nullptr;
}

// Calcular el total de ventas en todas las estaciones
double RedNacional::calcularVentasTotales() const {
    double totalVentas = 0.0;
    for (int i = 0; i < numEstaciones; ++i) {
        totalVentas += estaciones[i]->calcularVentas();
    }
    return totalVentas;
}

// Fijar precios de combustible por región
void RedNacional::fijarPreciosCombustible(int region, double precios[]) {
    if (region >= 0 && region < 3) {
        for (int i = 0; i < 3; ++i) {
            precios_combustible[i] = precios[i];
        }
    } else {
        cout << "Región no válida" << endl;
    }
}

