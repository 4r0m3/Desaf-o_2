#include "Surtidor.h"
#include <iostream>

using namespace std;
using namespace SurtidorNS;

// Constructor
Surtidor::Surtidor(const string& codigo, const string& nombre, const string& modelo)
    : Entidad(codigo, nombre), modelo(modelo), numVentas(0), capacidadVentas(2), activo(false) {
    ventas = new string[capacidadVentas];  // Inicializar el arreglo dinámico de ventas
}

// Destructor
Surtidor::~Surtidor() {
    delete[] ventas;  // Liberar el arreglo dinámico de ventas
}

// Redimensionar el arreglo de ventas
void Surtidor::redimensionarVentas(int nuevaCapacidad) {
    string* nuevoArreglo = new string[nuevaCapacidad];
    for (int i = 0; i < numVentas; ++i) {
        nuevoArreglo[i] = ventas[i];
    }
    delete[] ventas;
    ventas = nuevoArreglo;
    capacidadVentas = nuevaCapacidad;
}

// Registrar una nueva venta
void Surtidor::registrarVenta(const string& fecha, const string& hora, double cantidad, int categoria, const string& metodo_pago, const string& documento_cliente, double monto) {
    if (numVentas == capacidadVentas) {
        redimensionarVentas(capacidadVentas * 2);  // Duplicar la capacidad si está lleno
    }

    // Registrar la venta en formato string (podría personalizarse más según necesidades)
    ventas[numVentas++] = "Fecha: " + fecha + ", Hora: " + hora + ", Cantidad: " + to_string(cantidad) +
                          "L, Categoría: " + to_string(categoria) + ", Monto: " + to_string(monto);
}

// Activar el surtidor
void Surtidor::activar() {
    activo = true;
}

// Desactivar el surtidor
void Surtidor::desactivar() {
    activo = false;
}

// Verificar si el surtidor está activo
bool Surtidor::estaActivo() const {
    return activo;
}

// Calcular las ventas totales del surtidor (simulado, sumar las ventas)
double Surtidor::calcularVentas() const {
    double totalVentas = 0.0;
    for (int i = 0; i < numVentas; ++i) {
        // En este ejemplo asumimos que cada venta tiene el formato "..., Monto: X", extraemos el monto
        size_t pos = ventas[i].find("Monto: ");
        if (pos != string::npos) {
            totalVentas += stod(ventas[i].substr(pos + 7));  // Convertir el monto a double
        }
    }
    return totalVentas;
}

// Mostrar la información del surtidor
void Surtidor::mostrarInformacion() const {
    cout << "Surtidor modelo: " << modelo << " (Código: " << getCodigo() << ")\n";
    cout << "Estado: " << (activo ? "Activo" : "Inactivo") << endl;
}

// Mostrar el historial de transacciones
void Surtidor::mostrarHistoricoTransacciones() const {
    cout << "Historial de transacciones del surtidor " << getCodigo() << ":\n";
    for (int i = 0; i < numVentas; ++i) {
        cout << ventas[i] << endl;
    }
}
