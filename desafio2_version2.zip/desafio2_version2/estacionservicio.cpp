#include "EstacionServicio.h"
#include <iostream>
#include <cstdlib>  // Para generar números aleatorios

using namespace std;
using namespace EstacionServicioNS;

// Constructor
EstacionServicio::EstacionServicio(const string& codigo, const string& nombre, const string& ubicacion, const string& gerente, const string& region)
    : Entidad(codigo, nombre), gerente(gerente), region(region), ubicacion(ubicacion), numSurtidores(0), capacidadSurtidores(2) {
    surtidores = new Surtidor*[capacidadSurtidores];  // Inicializar el arreglo dinámico
    asignarCapacidadTanque();
}

// Destructor
EstacionServicio::~EstacionServicio() {
    for (int i = 0; i < numSurtidores; ++i) {
        delete surtidores[i];  // Liberar memoria de cada surtidor
    }
    delete[] surtidores;  // Liberar el arreglo dinámico
}

// Redimensionar el arreglo de surtidores
void EstacionServicio::redimensionarSurtidores(int nuevaCapacidad) {
    Surtidor** nuevoArreglo = new Surtidor*[nuevaCapacidad];
    for (int i = 0; i < numSurtidores; ++i) {
        nuevoArreglo[i] = surtidores[i];
    }
    delete[] surtidores;
    surtidores = nuevoArreglo;
    capacidadSurtidores = nuevaCapacidad;
}

// Agregar un surtidor
void EstacionServicio::agregarSurtidor(Surtidor* surtidor) {
    if (numSurtidores == capacidadSurtidores) {
        redimensionarSurtidores(capacidadSurtidores * 2);  // Duplicar la capacidad si está lleno
    }
    surtidores[numSurtidores++] = surtidor;
}

// Eliminar un surtidor
void EstacionServicio::eliminarSurtidor(const string& codigo) {
    for (int i = 0; i < numSurtidores; ++i) {
        if (surtidores[i]->getCodigo() == codigo) {
            delete surtidores[i];  // Liberar memoria del surtidor
            // Desplazar los surtidores
            for (int j = i; j < numSurtidores - 1; ++j) {
                surtidores[j] = surtidores[j + 1];
            }
            --numSurtidores;
            break;
        }
    }
}

// Buscar un surtidor por su código
Surtidor* EstacionServicio::buscarSurtidor(const string& codigo) {
    for (int i = 0; i < numSurtidores; ++i) {
        if (surtidores[i]->getCodigo() == codigo) {
            return surtidores[i];
        }
    }
    return nullptr;
}

// Activar un surtidor
void EstacionServicio::activarSurtidor(const string& codigo) {
    Surtidor* surtidor = buscarSurtidor(codigo);
    if (surtidor) {
        surtidor->activar();
    }
}

// Desactivar un surtidor
void EstacionServicio::desactivarSurtidor(const string& codigo) {
    Surtidor* surtidor = buscarSurtidor(codigo);
    if (surtidor) {
        surtidor->desactivar();
    }
}

// Calcular las ventas totales de la estación
double EstacionServicio::calcularVentas() const {
    double totalVentas = 0.0;
    for (int i = 0; i < numSurtidores; ++i) {
        totalVentas += surtidores[i]->calcularVentas();
    }
    return totalVentas;
}
// Consultar el histórico de transacciones de cada surtidor
void EstacionServicio::consultarHistoricoTransacciones() const {
    for (int i = 0; i < numSurtidores; ++i) {
        cout << "Histórico de transacciones para el surtidor " << surtidores[i]->getCodigo() << ":\n";
        surtidores[i]->mostrarHistoricoTransacciones();
        cout << endl; // Añadir un salto de línea para mayor claridad
    }
}

// Asignar capacidad al tanque de la estación
void EstacionServicio::asignarCapacidadTanque() {
    for (int i = 0; i < 3; ++i) {
        capacidad_tanque[i] = (rand() % 100) + 100;  // Asignar una capacidad entre 100 y 200 litros
    }
}
void EstacionServicio::simularVenta(double litros, int categoria) {
    // Validar la categoría
    if (categoria < 0 || categoria >= 3) {
        cout << "Categoría inválida. Debe ser 0, 1 o 2." << endl;
        return;
    }

    // Verificar si hay surtidores activos
    for (int i = 0; i < numSurtidores; ++i) {
        if (surtidores[i]->estaActivo()) {
            // Simulamos la venta
            // Ejemplo de llamada a registrarVenta
            surtidores[i]->registrarVenta("2024-10-18", "14:30", litros, categoria, "tarjeta", "123456", litros * 1.5); // Monto simulado
            cout << "Venta de " << litros << " litros en el surtidor " << surtidores[i]->getCodigo() << " realizada." << endl;
            return; // Solo simula una venta por llamada
        }
    }
    cout << "No hay surtidores activos disponibles." << endl;
}
