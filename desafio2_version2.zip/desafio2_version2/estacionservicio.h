#ifndef ESTACIONSERVICIO_H
#define ESTACIONSERVICIO_H

#include <string>
#include "Entidad.h"
#include "Surtidor.h"
using namespace SurtidorNS;
using namespace std;

namespace EstacionServicioNS {

class EstacionServicio : public Entidad {
public:
    // Constructor y destructor
    EstacionServicio(const string& codigo, const string& nombre, const string& ubicacion, const string& gerente, const string& region);
    ~EstacionServicio();

    // Métodos
    void agregarSurtidor(Surtidor* surtidor);
    void eliminarSurtidor(const string& codigo);
    Surtidor* buscarSurtidor(const string& codigo);
    void activarSurtidor(const string& codigo);
    void desactivarSurtidor(const string& codigo);
    double calcularVentas() const;
    void asignarCapacidadTanque();
    void consultarHistoricoTransacciones()const;
    void simularVenta(double litros, int categoria); // Agregar declaración


private:
    string gerente;
    string region;
    string ubicacion;
    double capacidad_tanque[3];  // Capacidad de almacenamiento por categoría

    Surtidor** surtidores;  // Arreglo dinámico de punteros a Surtidor
    int numSurtidores;  // Número de surtidores en la estación
    int capacidadSurtidores;  // Capacidad del arreglo dinámico

    void redimensionarSurtidores(int nuevaCapacidad);  // Redimensionar el arreglo
};

}

#endif // ESTACIONSERVICIO_H
