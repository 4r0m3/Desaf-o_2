#ifndef ENTIDAD_H
#define ENTIDAD_H

#include <string>

using namespace std;  // Usar el namespace std en todo el archivo

class Entidad {
public:
    // Constructor
    Entidad(const string& codigo, const string& nombre)
        : codigo(codigo), nombre(nombre) {}

    // Métodos virtuales (pueden ser sobrescritos por clases derivadas)
    virtual ~Entidad() {}  // Destructor virtual, importante para la herencia

    // Getters
    string getCodigo() const {
        return codigo;
    }

    string getNombre() const {
        return nombre;
    }

    // Setters
    void setCodigo(const string& nuevoCodigo) {
        codigo = nuevoCodigo;
    }

    void setNombre(const string& nuevoNombre) {
        nombre = nuevoNombre;
    }

private:
    string codigo;
    string nombre;
};

#endif // ENTIDAD_H

