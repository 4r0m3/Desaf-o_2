#ifndef SURTIDOR_H
#define SURTIDOR_H
#include "Entidad.h"
#include <string>

using namespace std;

namespace SurtidorNS {

class Surtidor : public Entidad {
public:
    // Constructor y destructor
    Surtidor(const string& codigo, const string& nombre, const string& modelo);
    ~Surtidor();  // Destructor para liberar memoria

    // Métodos
    void registrarVenta(const string& fecha, const string& hora, double cantidad, int categoria, const string& metodo_pago, const string& documento_cliente, double monto);
    void activar();
    void desactivar();
    bool estaActivo() const;
    double calcularVentas() const;
    void mostrarInformacion() const;
    void mostrarHistoricoTransacciones() const;

private:
    string modelo;  // Modelo del surtidor
    string* ventas;  // Arreglo dinámico de ventas
    int numVentas;  // Número actual de ventas
    int capacidadVentas;  // Capacidad del arreglo de ventas
    bool activo;  // Estado del surtidor (activo o no)

    void redimensionarVentas(int nuevaCapacidad);  // Redimensionar el arreglo de ventas
};

}

#endif // SURTIDOR_H

